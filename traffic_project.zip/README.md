
Traffic Congestion Prediction — Project Repo
============================================

This repository contains a Jupyter-friendly Python project for:
- synthetic traffic & survey data generation (Police & PSV)
- training classification models (Random Forest, MLP, Linear Regression thresholded)
- visualizations (matplotlib / seaborn)
- MySQL integration helpers (create DB/tables + insert predictions)
- example test datasets (Excel files)

Files in this repo:
- main_notebook.py         : runnable script / notebook cell code
- config/mysql_config.py   : example DB credentials (edit before use)
- requirements.txt         : pip install list
- LICENSE                  : MIT License
- test_data_42_realistic.xlsx : sample dataset (42 rows)
- README.md                : this file

How to run
1. Install dependencies: pip install -r requirements.txt
2. Edit config/mysql_config.py with your DB credentials.
3. Run main_notebook.py in Jupyter or as a script for training, plots and DB inserts.
4. Optional: run app.py (Flask) or streamlit_app.py for API/UI (not included in the minimal zip).

Notes
- This project is original and written to be easy to extend.
- The MIT license allows reuse and modifications.
