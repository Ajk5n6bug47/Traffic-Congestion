
# Edit these values to match your MySQL server before running the project
host = "localhost"
port = 3306
user = "Japheth"
password = "Japheth@3577"
database = "myDB"
