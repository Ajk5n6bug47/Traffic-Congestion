
# Traffic Congestion Prediction — main script (Jupyter-friendly)
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import joblib
import os
import mysql.connector
from mysql.connector import Error
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LinearRegression
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

sns.set(style="whitegrid")
np.random.seed(42)

# -----------------------
# Generate survey & traffic data
# -----------------------
police_df = pd.DataFrame({"hour": np.random.randint(0,24,300)})
police_df["reported_thefts"] = (police_df["hour"].isin([6,7,8,18,19,20])).astype(int) + np.random.randint(0,3,300)

psv_df = pd.DataFrame({"hour": np.random.randint(0,24,400)})
psv_df["traffic_heavy"] = (psv_df["hour"].isin([6,7,8,16,17,18])).astype(int) + np.random.randint(0,3,400)

traffic_df = pd.DataFrame({
    "hour": np.random.randint(0,24,800),
    "vehicles": np.random.randint(10,900,800),
    "weather": np.random.randint(0,3,800)
})
traffic_df["congestion"] = (((traffic_df["vehicles"] > 500) | (traffic_df["weather"]==2))).astype(int)

# Simple EDA plots (can be run in notebook cells)
plt.figure(figsize=(10,4)); sns.countplot(x=police_df["hour"]); plt.title("Police thefts by hour"); plt.show()
plt.figure(figsize=(10,4)); sns.countplot(x=psv_df["hour"]); plt.title("PSV heavy traffic by hour"); plt.show()
plt.figure(figsize=(8,5)); sns.heatmap(traffic_df.corr(), annot=True, cmap="coolwarm"); plt.title("Traffic correlation"); plt.show()

# -----------------------
# Prepare features and split
# -----------------------
FEATURES = ["hour","vehicles","weather"]
X = traffic_df[FEATURES]
y = traffic_df["congestion"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)

# -----------------------
# Train models
# -----------------------
rf = RandomForestClassifier(n_estimators=200, random_state=42, class_weight="balanced")
rf.fit(X_train, y_train)
rf_preds = rf.predict(X_test)
rf_acc = accuracy_score(y_test, rf_preds)

nn = MLPClassifier(hidden_layer_sizes=(32,16), max_iter=2000, random_state=42)
nn.fit(X_train, y_train)
nn_preds = nn.predict(X_test)
nn_acc = accuracy_score(y_test, nn_preds)

lr = LinearRegression()
lr.fit(X_train, y_train)
lr_preds = (lr.predict(X_test) >= 0.5).astype(int)
lr_acc = accuracy_score(y_test, lr_preds)

print("RF acc:", rf_acc, "NN acc:", nn_acc, "LR acc:", lr_acc)
print(classification_report(y_test, rf_preds, zero_division=1))

# -----------------------
# Save models
# -----------------------
models_path = os.path.join(".", "models_all.joblib")
joblib.dump({"rf": rf, "nn": nn, "lr": lr}, models_path)

# -----------------------
# DB helper: create tables and insert example predictions
# -----------------------
def ensure_db_and_tables(cfg):
    try:
        conn = mysql.connector.connect(host=cfg['host'], user=cfg['user'], password=cfg['password'], port=cfg.get('port',3306))
        cur = conn.cursor()
        cur.execute(f"CREATE DATABASE IF NOT EXISTS `{cfg['database']}`;")
        conn.commit()
        cur.close(); conn.close()
    except Error as e:
        print('DB create error:', e)
        return False
    try:
        conn = mysql.connector.connect(host=cfg['host'], user=cfg['user'], password=cfg['password'], database=cfg['database'], port=cfg.get('port',3306))
        cur = conn.cursor()
        cur.execute(\"\"\"CREATE TABLE IF NOT EXISTS model_performance (
            id INT AUTO_INCREMENT PRIMARY KEY,
            model_name VARCHAR(100),
            accuracy DOUBLE,
            run_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );\"\"\")
        cur.execute(\"\"\"CREATE TABLE IF NOT EXISTS traffic_predictions (
            id INT AUTO_INCREMENT PRIMARY KEY,
            hour INT, vehicles INT, weather INT,
            predicted_congestion INT, model_used VARCHAR(100),
            predicted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );\"\"\")
        conn.commit(); cur.close(); conn.close()
        return True
    except Error as e:
        print('Table create error:', e)
        return False

# write config file if not present
cfg_path = os.path.join("config", "mysql_config.py")
if os.path.exists(cfg_path):
    from config.mysql_config import host, port, user, password, database
    cfg = {"host": host, "port": port, "user": user, "password": password, "database": database}
    ok = ensure_db_and_tables(cfg)
    if ok:
        try:
            conn = mysql.connector.connect(host=cfg['host'], user=cfg['user'], password=cfg['password'], database=cfg['database'], port=cfg['port'])
            cur = conn.cursor()
            cur.executemany("INSERT INTO model_performance (model_name, accuracy) VALUES (%s, %s)",
                            [("Random Forest", float(rf_acc)), ("Neural Network", float(nn_acc)), ("Linear Regression (threshold)", float(lr_acc))])
            conn.commit()
            # insert a few prediction rows (rf)
            rows = []
            for i in range(len(X_test)):
                rows.append((int(X_test.iloc[i]['hour']), int(X_test.iloc[i]['vehicles']), int(X_test.iloc[i]['weather']), int(rf_preds[i]), "Random Forest"))
            cur.executemany("INSERT INTO traffic_predictions (hour, vehicles, weather, predicted_congestion, model_used) VALUES (%s,%s,%s,%s,%s)", rows[:20])
            conn.commit()
            cur.close(); conn.close()
            print('Inserted sample predictions into DB.')
        except Exception as e:
            print('Insert sample error:', e)
else:
    print('No config/mysql_config.py found — DB insert skipped.')
